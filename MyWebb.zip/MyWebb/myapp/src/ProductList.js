// import React from 'react';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';

// const ProductList = ({ products, addToCart }) => {
//   return (
//     <div className="product-list ms-auto">
//       {products.map((product) => (
//         <div key={product.id} className="product-item" >
//           <img src={product.image} alt={product.name} className="image"/>
//           <h3>{product.name}</h3>
//           <div className="price-container">
//             <div className="price-circle">
//               {product.price.toLocaleString('sv-SE')} kr
//             </div>
//           </div>
//           <button className="add-to-cart-button" onClick={() => addToCart(product)}>
//          Köp <FontAwesomeIcon icon={faShoppingCart} size="1x" />
//           </button>
//         </div>
//       ))}
//     </div>
//   );
// };

// export default ProductList;
