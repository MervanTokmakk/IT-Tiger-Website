import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import { BsPerson } from 'react-icons/bs';
import Cart from './Cart';
import CartItem from './CartItem'; 

const Header = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');


  const handleLogin = () => {
    setShowLogin((prevShowLogin) => !prevShowLogin); 
  };

  const handleLoginFormSubmit = (event) => {
    event.preventDefault();
    // Här kan du implementera din inloggningslogik med användarnamn och lösenord
    // Kontrollera användarnamn och lösenord här, och om de stämmer överens, sätt isLoggedIn till true
    setIsLoggedIn(true);
    setShowLogin(false); // Stäng inloggningsformuläret efter inloggning
  };

  

  return (
    <header  className="d-flex justify-content-center align-items-center bg-dark text-white p-3">
      {/* Logotyp */}
    <img src="/Tiger.png" className="logo" style={{ marginRight: '2rem' }} />
<style>
@import url('https://fonts.googleapis.com/css2?family=Bungee+Spice&display=swap');
</style>

      {/* Rubrik */}
      <h1> IT Tiger</h1>

      {/* Sökruta */}
      <input
        type="search"
        placeholder="Sök produkt..."
        className="search"
      />
        <div className="d-flex">
          <button className="button-login" onClick={handleLogin}>
            Logga in
          <div className="ms-auto">
            <BsPerson size={24} />
          </div>
          </button>
          {showLogin && (
            <form onSubmit={handleLoginFormSubmit}>
              <input
                type="text"
                placeholder="Användarnamn"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="form-control me-2"
              />
              <input
                type="password"
                placeholder="Lösenord"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="form-control me-2"
              />
               {/* Kundvagn */}
            </form>
          )}
        <div className="product-item">
        <button > 
          <FontAwesomeIcon icon={faShoppingCart} size="1x" style={{ marginRight: '0.5rem' }}/>Kundvagn
        </button>
      </div>
        </div>

    </header>
  );
};

export default Header;
