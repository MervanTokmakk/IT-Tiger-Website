import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart, faTags } from '@fortawesome/free-solid-svg-icons';

const TopProductList = ({ products, addToCart }) => {
  return (
    <div className="product-list ms-auto">
      {products.map((product) => (
        <div key={product.id} className="product-item">
          <div className="price-container">
            <div className="top-price-circle">
              <FontAwesomeIcon icon={faTags} size="lg" />
              {product.price.toLocaleString('sv-SE')} kr
            </div>
          </div>
          <img src={product.image} alt={product.name} className="image" />
          <div>{product.name}</div>
          <button onClick={() => addToCart(product)}>
            <FontAwesomeIcon icon={faShoppingCart} size="1x" style={{ color: 'white' }} />
          </button>
        </div>
      ))}
    </div>
  );
};

export default TopProductList;
