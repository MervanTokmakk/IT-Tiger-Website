// I Cart.js
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import CartItem from './CartItem';

const Cart = ({ cartItems, total, updateQuantity }) => {
  return (
    <div className="cart bg-success text-white p-3 ms-auto">
      <div className="d-flex flex-column align-items-center">
        <h3 style={{ fontSize: '1.5rem' }}>Kundvagn</h3>
        <div className="d-flex flex-column align-items-center justify-content-center">
          {cartItems.map((item) => (
            <CartItem key={item.id} item={item} updateQuantity={updateQuantity} />
          ))}
        </div>
        <p>Totalt: {total} kr
          <FontAwesomeIcon icon={faShoppingCart} size="1x" style={{ color: 'white' }} />
        </p>
      </div>
    </div>
  );
};

export default Cart;
