import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';
import { BiPersonCircle } from 'react-icons/bi';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import Header from './Header';
import ProductList from './ProductList';
import NewProductList from './NewProductList';
import TopProductList from './TopProductList';
import Cart from './Cart';
import CartItem from './CartItem';
import './index.css';

const App = () => {
  // State för produkter och kundvagn
  const [newProducts, setNewProducts] = useState([
    { id: 1, name: 'Inet System G70 R7X3D/4080', price: 35499, image: 'NewProducts/Inet_System.png'},
    { id: 2, name: 'Acer Predator Orion 3000 - i7 | 16GB | 1TB | RTX 3070', price: 14900, image: 'NewProducts/Acer_Predator.png' },
    { id: 3, name: 'Taurus Gaming GTX 1650 - 13100F', price: 9990, image: 'NewProducts/Taurus.png' },
    
  ]);
  
  const [topProducts, setTopProducts] = useState([
    { id: 1, name: 'Logitech G PRO Wireless', price: 1090, image: 'TopList/Logitech.png'},
    { id: 2, name: 'Elgato Stream Deck + Svart', price: 2690, image: 'Toplist/Elgato_Stream.png' },
    { id: 3, name: 'Corsair Gaming K65 RGB Mini Cherry MX Red Vit', price: 590, image: 'TopList/Corsair_Gaming.png'},

  ]);

  const [cartItems, setCartItems] = useState([]);
  const [total, setTotal] = useState(0);

  // Lägg till produkt i kundvagnen
  const addToCart = (product) => {
    const existingItem = cartItems.find((item) => item.id === product.id);

    if (existingItem) {
      const updatedCartItems = cartItems.map((item) =>
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      );
      setCartItems(updatedCartItems);
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1 }]);
    }
  };

  // Uppdatera produktens antal i kundvagnen
  const updateQuantity = (productId, newQuantity) => {
    const updatedCartItems = cartItems.map((item) =>
      item.id === productId ? { ...item, quantity: newQuantity } : item
    );
    setCartItems(updatedCartItems);
  };

  // Ta bort produkt från kundvagnen
  const removeFromCart = (productId) => {
    const updatedCartItems = cartItems.filter((item) => item.id !== productId);
    setCartItems(updatedCartItems);
  };

  // Beräkna totala summan av produkterna i kundvagnen
  useEffect(() => {
    const totalPrice = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
    setTotal(totalPrice);
  }, [cartItems]);

  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <div className={`app ${isDarkMode ? 'dark-mode' : 'light-mode'}`}>
      <div className="form-check form-switch">
        <input
          className="form-check-input"
          type="checkbox"
          id="darkModeSwitch"
          checked={isDarkMode}
          onChange={toggleDarkMode}
        />
        <label className="form-check-label" htmlFor="darkModeSwitch">
          Dark Mode
        </label>
      </div>
      <Header/>

       {/* Kampanjer Section */}
      <div className='subheading'> Kampanjer</div>

      <Carousel showArrows={false} showStatus={false} showThumbs={false} interval={5000}>
        <div>
          <img src="Kampanj/Razer.png" style={{ width: '20%', height: 'auto' }} />
          <div style={{ marginTop: '30px', padding: '30px' }}>Razer 27" Raptor QHD IPS 165 Hz</div>
        </div>
        <div>
          <img src="Kampanj/AOC.png" style={{ width: '20%', height: 'auto' }} />
          <div style={{ marginTop: '30px', padding: '30px' }}>AOC 27" AGON AG276QZD OLED QHD 240 Hz</div>
        </div>
        <div>
          <img src="Kampanj/MSI.png" style={{ width: '20%', height: 'auto' }}/>
          <div style={{ marginTop: '30px', padding: '60px' }}>MSI 32" Optix G32CQ4 E2 QHD VA Curved 170 Hz</div>
        </div>
      </Carousel>

      {/* Nya produkter Section */}
      <div className='subheading'>Nya produkter</div>
        <main className="d-flex justify-content-center">
          <div className="row">
            <div className="col">
              <NewProductList products={newProducts} addToCart={addToCart}/>
            </div>
          </div>
        </main>

      {/* Toplista Section */}
      <div className='subheading text-center'>Topplista</div>
        <main className="d-flex justify-content-center">
          <div className="row">
            <div className="col">
              <TopProductList products={topProducts} addToCart={addToCart}/>
            </div>
          </div>
        </main>
      </div>
  );
};

export default App;
